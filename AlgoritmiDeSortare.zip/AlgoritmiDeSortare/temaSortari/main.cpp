#include <bits/stdc++.h>
#include <chrono>
#include "Algoritmi/quicksort.h"
#include "Algoritmi/bubblesort.h"
#include "Algoritmi/rrand.hpp"
#include "Algoritmi/countsort.h"
#include "Algoritmi/mergesort.h"
#include "Algoritmi/radixsort.h"

#define Nmax 1000005

using namespace std;
using namespace std::chrono;

int N;
int V[Nmax];
int freq[10 * Nmax];
int B[Nmax];
int aux[Nmax];
int bucket[2][1000005];

char pivotType[][100] = {"q", "Pivot cu valoare random din subvector", "Pivot cu valoarea egala cu cea din mijlocul subvectorului", "Pivot cu valoarea mediana a 10 valori random din subvector"};

int sz[] =     {0, 100, 1000, 10000, 100000, 1000000 ,  54251    , 100000  ,  100000  ,  1000000  ,     500000, 105     , 1000000  , 1000000};
int maxVal[] = {0, 4  , 100 , 1000 , 10000 , 100000  , 1000000000, 10000000, 100000000, 1000000000, 1000000000, 10000000, 10000000 , 1000000};


bool testSort(int *V, int N)
{
    for(int i = 2; i <= N; i++)
        if(V[i] < V[i - 1])
            return false;
    return true;
}

void generateTest(int t, ofstream &fout)
{
    N = sz[t];
    fout << N << " numere naturale\n";
    fout << maxVal[t] << " valoarea maxima\n\n";
    for(int i = 1; i <= N; i++)
        V[i] = R() % maxVal[t];
    memcpy(aux, V, sizeof(V));
}

string integerToString(int X)
{
    string ret;
    while(X)
    {
        ret.push_back('0' + X % 10);
        X /= 10;
    }
    reverse(ret.begin(), ret.end());
    return ret;
}

int main()
{
    srand(time(NULL));
    int T;
    //cin >> T;
    T = 13;
    for(int t = 1; t <= T; t++)
    {
        string outFile = string("Test") + integerToString(t) + string(".txt");

        ofstream fout(outFile);

        fout << "Testul " << t << "\n\n";

        generateTest(t, fout);

        memcpy(V, aux, sizeof(aux));
        fout << "*-- Bubble Sort --*\n\n";

        if(N <= 10000)
        {
            auto start = high_resolution_clock::now();
            bubbleSort(V, N);
            auto stop = high_resolution_clock::now();

            auto duration = duration_cast <microseconds>(stop - start);

            fout << "Timp de executie: " << duration.count() / 1e6 << " secunde \n";
            fout << "A sortat corect: " << (testSort(V, N) == true ? "DA\n" : "NU\n");
            fout << "\n";
        }
        else
            fout << "Bubble Sort nu doreste sa prajeasca procesorul\n\n";

        memcpy(V, aux, sizeof(aux));
        fout << "*-- Count Sort --*\n\n";

        if(maxVal[t] <= 10000000)
        {
            auto start = high_resolution_clock::now();
            countSort(V, freq, N, maxVal[t]);
            auto stop = high_resolution_clock::now();

            auto duration = duration_cast <microseconds>(stop - start);

            fout << "Timp de executie: " << duration.count() / 1e6 << " secunde \n";
            fout << "A sortat corect: " << (testSort(V, N) == true ? "DA\n" : "NU\n");
            fout << "\n";
        }
        else
            fout << "Count Sort nu crede ca ii puteti oferi memoria necesara\n\n";

        fout << "*-- Quick Sort -- *\n\n";

        for(int i = 1; i <= 3; i++)
        {
            memcpy(V, aux, sizeof(aux));
            fout << pivotType[i] << "\n\n";
            auto start = high_resolution_clock::now();
            quickSort(V, 1, N, i);
            auto stop = high_resolution_clock::now();

            auto duration = duration_cast <microseconds>(stop - start);

            fout << "Timp de executie: " << duration.count() / 1e6 << " secunde \n";
            fout << "A sortat corect: " << (testSort(V, N) == true ? "DA\n" : "NU\n");
            fout << "\n";
        }

        fout << "*-- Merge Sort --*\n\n";

        memcpy(V, aux, sizeof(V));
        auto start = high_resolution_clock::now();
        mergeSort(V, B, 1, N);
        auto stop = high_resolution_clock::now();

        auto duration = duration_cast <microseconds>(stop - start);

        fout << "Timp de executie: " << duration.count() / 1e6 << " secunde \n";
        fout << "A sortat corect: " << (testSort(V, N) == true ? "DA\n" : "NU\n");
        fout << "\n";

        fout << "*-- Radix Sort --*\n\n";

        memcpy(V, aux, sizeof(V));
        start = high_resolution_clock::now();
        radixSort(V, bucket[0], bucket[1], 1, N);
        stop = high_resolution_clock::now();
        duration = duration_cast <microseconds>(stop - start);

        fout << "Timp de executie: " << duration.count() / 1e6 << " secunde \n";
        fout << "A sortat corect: " << (testSort(V, N) == true ? "DA\n" : "NU\n");
        fout << "\n";
        fout << "*-----------------------------*\n\n\n";
    }
    return 0;
}

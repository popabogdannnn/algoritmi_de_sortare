#include "bubblesort.h"
#include <bits/stdc++.h>

using namespace std;

void bubbleSort(int *V, int N)
{
    bool ok = true;
    while(ok)
    {
        ok = false;
        for(int i = 1; i < N; i++)
            if(V[i] > V[i + 1])
            {
                swap(V[i], V[i + 1]);
                ok = true;
            }
    }
}

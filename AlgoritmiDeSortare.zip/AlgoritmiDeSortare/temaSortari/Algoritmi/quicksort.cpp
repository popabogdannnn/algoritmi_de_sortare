#include <bits/stdc++.h>

#include "quicksort.h"
#include "bubblesort.h"
#include "rrand.hpp"

using namespace std;


int pivotMidOfRange(int *V, int le, int ri)
{
    return V[(le + ri) / 2];
}

int pivotRandomInRange(int *V, int le, int ri)
{
    return V[le + R() % (ri - le + 1)];
}

int pivotMedianOf10Random(int *V, int le, int ri)
{
    int aux[11];
    for(int i = 1; i <= 10; i++)
        aux[i] = V[le + R() % (ri - le + 1)];
    bubbleSort(aux, 10);
    return aux[5];
}

void quickSort(int *V, int le, int ri, int t)
{
    if(le >= ri)
        return;
    int piv;
        if(t == 1)
            piv = pivotMidOfRange(V, le, ri);
        else
            if(t == 2)
                piv = pivotRandomInRange(V, le, ri);
            else
                piv = pivotMedianOf10Random(V, le, ri);
    int i = le, j = ri;
    while(i <= j)
    {
        while(i < ri && V[i] < piv)
            i++;
        while(j > le && V[j] > piv)
            j--;
        if(i <= j)
        {
            swap(V[i], V[j]);
            i++;
            j--;
        }
    }
    quickSort(V, le, j, t);
    quickSort(V, i, ri, t);
}

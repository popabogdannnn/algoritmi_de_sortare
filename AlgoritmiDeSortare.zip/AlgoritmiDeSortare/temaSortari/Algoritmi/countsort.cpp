#include "countsort.h"
#include <bits/stdc++.h>

using namespace std;

void countSort(int *V, int *freq, int N, int maxVal)
{
    for(int i = 0; i <= maxVal; i++)
        freq[i] = 0;
    for(int i = 1; i <= N; i++)
        freq[V[i]]++;
    int l = 0;
    for(int i = 0; i <= maxVal; i++)
        while(freq[i]--)
            V[++l] = i;
}

#ifndef QUICKSORT_H_INCLUDED
#define QUICKSORT_H_INCLUDED

int pivotMidOfRange(int *, int , int);
int pivotRandomInRange(int *, int , int);
int pivotMedianOf10Random(int *, int , int);
void quickSort(int *, int , int , int );

#endif // QUICKSORT_H_INCLUDED

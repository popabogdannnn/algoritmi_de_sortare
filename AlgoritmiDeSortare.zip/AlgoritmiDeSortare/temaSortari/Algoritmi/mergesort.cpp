#include "mergesort.h"
#include <bits/stdc++.h>

using namespace std;

void mergeSort(int *V, int *B , int le, int ri)
{
    if(le == ri)
        return;
    int mid = (le + ri) / 2;
    mergeSort(V, B, le, mid);
    mergeSort(V, B, mid + 1, ri);
    int j = mid + 1;
    int c = le;
    for(int i = le; i <= mid; i++)
    {
        while(V[j] <= V[i] && j <= ri)
            B[c++] = V[j++];
        B[c++] = V[i];
    }
    while(j <= ri)
        B[c++] = V[j++];
    for(int i = le; i <= ri; i++)
        V[i] = B[i];
}

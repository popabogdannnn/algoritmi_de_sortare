#ifndef MERGESORT_H_INCLUDED
#define MERGESORT_H_INCLUDED

void mergeSort(int *, int *, int , int);

#endif // MERGESORT_H_INCLUDED

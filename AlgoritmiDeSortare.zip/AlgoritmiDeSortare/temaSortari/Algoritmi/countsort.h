#ifndef COUNTSORT_H_INCLUDED
#define COUNTSORT_H_INCLUDED

void countSort(int *, int *, int , int);

#endif // COUNTSORT_H_INCLUDED

#include "radixsort.h"
#include <bits/stdc++.h>

using namespace std;

void radixSort(int *V, int *b0, int *b1, int le, int ri, int b)
{
    if(le > ri)
        return;
    b0[0] = b1[0] = 0;
    for(int i = le; i <= ri; i++)
        if(V[i] & (1 << b))
            b1[++b1[0]] = V[i];
        else
            b0[++b0[0]] = V[i];
    int p = le;
    for(int i = 1; i <= b0[0]; i++)
        V[p++] = b0[i];
    int mid = p;
    for(int i = 1; i <= b1[0]; i++)
        V[p++] = b1[i];
    if(b > 0)
    {
        radixSort(V, b0, b1, le, mid - 1, b - 1);
        radixSort(V, b0, b1, mid, ri, b - 1);
    }
}

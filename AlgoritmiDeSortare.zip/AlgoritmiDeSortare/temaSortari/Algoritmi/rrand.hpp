#ifndef RRAND_HPP_INCLUDED
#define RRAND_HPP_INCLUDED

int R();

#endif // RRAND_HPP_INCLUDED

#include <bits/stdc++.h>
#include "rrand.hpp"

int cnt = 0;

int R()
{
    if(cnt == 0)
        srand(time(NULL));
    cnt++;
    return rand() * rand();
}

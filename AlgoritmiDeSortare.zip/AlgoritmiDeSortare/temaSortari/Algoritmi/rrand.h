#ifndef RRAND_H_INCLUDED
#define RRAND_H_INCLUDED

int R();

#endif // RRAND_H_INCLUDED
